package hello_world;

import java.util.Scanner;

public class trocaDeValor {

	public static void main(String[] args) {
		String nome1;
		String nome2;
		String aux;
		
		Scanner input = new Scanner(System.in);
		
		nome1 = " é o mestre do universo";
		nome2 = "";
		
		System.out.println("Troca valores entre variáveis");
		System.out.println("Qual o seu nome?: ");
		
		nome2 = input.nextLine();
		aux = nome2;
		nome2 = nome1;
		nome1 = aux;
		
		System.out.println(nome1 + nome2);

	}

}
