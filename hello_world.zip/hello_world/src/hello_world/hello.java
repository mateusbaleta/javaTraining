package hello_world;

import java.util.Scanner;


public class hello {

	public static void main(String[] args) {
		String nome = "";
		Scanner input = new Scanner(System.in);
		
		
		System.out.println("Bem vindo!");
		System.out.println("Qual é o seu nome?: ");
		nome = input.nextLine();
		System.out.println("Olá " + nome);

	}

}
