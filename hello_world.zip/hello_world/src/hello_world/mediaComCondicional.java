package hello_world;

import java.util.Scanner;

public class mediaComCondicional {

	public static void main(String[] args) {
		
		String nome;
		float n1 = 0;
		float n2 = 0;
		float n3 = 0;
		float n4 = 0;
		double total = 0;
		double media = 0;
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Calcular a média!\n");
		
		System.out.println("Digite o nome do aluno: ");
		nome = input.nextLine();
		
		System.out.println("Digite a 1a nota: ");
		n1 = input.nextFloat();
		
		System.out.println("Digite a 2a nota: ");
		n2 = input.nextFloat();
		
		System.out.println("Digite a 3a nota: ");
		n3 = input.nextFloat();
		
		System.out.println("Digite a 4a nota: ");
		n4 = input.nextFloat();
		
		total = n1+n2+n3+n4;
		media = total/4;
		
		if (media >= 6) {
			System.out.printf("O resultado da média foi: " + media);
			System.out.println("Aluno aprovado");
		}
		else {
			System.out.printf("O resultado da média foi: " + media, "\n");
			System.out.println("Aluno reprovado");
		}
		
		
		
		

	}

}
